<?php $__env->startSection('admin'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Manage's Teacher</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Manage</a></li>
                        <li class="breadcrumb-item active">Teacher</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between">
                <h4 class="card-title">View Teacher Info</h4>

                <a href="<?php echo e(route('add.teacher')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create
                    Teacher</a>
            </div>

            <table id="datatable" class="table table-bordered dt-responsive nowrap"
                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Father Name</th>
                        <th>Roll ID</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Gender</th>
                        <th>Department</th>
                        <th>National ID</th>
                        <th>Teacher image </th>
                        
                        <th class="all">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($teacher->first_name); ?></td>
                            <td><?php echo e($teacher->last_name); ?></td>
                            <td><?php echo e($teacher->father_name); ?></td>
                            <td><?php echo e($teacher->roll_id); ?></td>
                            <td><?php echo e($teacher->email); ?></td>
                            <td><?php echo e($teacher->phone); ?></td>
                            <td><?php echo e($teacher->gender); ?></td>
                            <td><?php echo e($teacher->department->depart_name); ?></td>
                            <td><?php echo e($teacher->national_id); ?></td>
                            <td>
                                <img class="header-profile-user"
                                    src="<?php echo e(!empty($teacher->photo) ? asset($teacher->photo) : asset('uploads/no_image.png')); ?>"
                                    alt="Header Avatar">

                            </td>
                            
                            <td style="text-align:center; font-size: 20px;" class="all">
                                <a href="<?php echo e(route('edit.teacher', $teacher->id)); ?>"><i
                                        class="fas fa-edit btn btn-primary waves-effect waves-light"></i></a>
                                <a href="<?php echo e(route('delete.teacher', $teacher->id)); ?>" id="delete"><i
                                        class="fas fa-trash-alt btn btn-danger waves-effect waves-light"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\teacher\manage_teacher.blade.php ENDPATH**/ ?>