<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class pending extends Model
{
    //
    protected $guarded = [];
}
