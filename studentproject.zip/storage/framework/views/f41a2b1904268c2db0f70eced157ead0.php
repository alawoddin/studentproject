<?php $__env->startSection('admin'); ?>

    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between">
                <h4 class="card-title">View Expenses</h4>
                <a href="<?php echo e(route('add.expense')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create
                    Expense</a>
            </div>

            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="width: 100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Note</th>
                        <th class="all">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->amount); ?> AF</td>
                            <td><?php echo e($item->date); ?></td>
                            <td><?php echo e($item->note); ?></td>
                            <td style="text-align:center; font-size: 20px;">
                                <a href="<?php echo e(route('edit.expense', $item->id)); ?>"><i class="fas fa-edit btn btn-primary"></i></a>
                                <a href="<?php echo e(route('delete.expense', $item->id)); ?>" id="delete"><i
                                        class="fas fa-trash-alt btn btn-danger"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\expense\manage_expense.blade.php ENDPATH**/ ?>