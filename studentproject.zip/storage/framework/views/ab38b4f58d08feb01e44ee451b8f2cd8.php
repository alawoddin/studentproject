<?php $__env->startSection('admin'); ?>

    <h4>Edit Expense</h4>

    <form action="<?php echo e(route('update.expense', $expense->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label>Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo e($expense->title); ?>">
        </div>
        <div>
            <label>Amount</label>
            <input type="number" name="amount" step="0.01" class="form-control" value="<?php echo e($expense->amount); ?>">
        </div>
        <div>
            <label>Date</label>
            <input type="date" name="date" class="form-control" value="<?php echo e($expense->date); ?>">
        </div>
        <div>
            <label>Note</label>
            <textarea name="note" class="form-control"><?php echo e($expense->note); ?></textarea>
        </div>
        <br>
        <button type="submit" class="btn btn-success">Update Expense</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\expense\edit_expense.blade.php ENDPATH**/ ?>