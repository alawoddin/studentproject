<?php $__env->startSection('admin'); ?>

    <div class="container-fluid">

        <!-- Breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <nav class="fs-4" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="#" class="fw-bold">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($teacher->first_name); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

 <!-- Main Content -->
<div class="row">
    <!-- Table Section -->
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">
                    Amount Information
                    <?php if(request('subject_id')): ?>
                        <small class="text-muted"> - Filtered by subject</small>
                    <?php endif; ?>
                </h4>

                

                <div class="table-responsive">
                    <table class="table table-centered mb-0 align-middle table-hover table-nowrap">
                        <thead class="table-light">
                            <tr>
                                <th>Sl</th>
                                <th>Department</th>
                                <th>Subject Name</th>
                                <th>Students</th>
                                <th>Total Fees</th>
                                <th>Paid</th>
                                
                                <th>Date</th>
                                <th>Paid status </th>
                                <th class="all">Action</th>
                                <th>Total of Salary</th>
                            </tr>
                        </thead>

                        <?php
                            $totalPaid = $paids->sum('paid');
                            $percentage = $teacher->percentage;
                            $commission = $totalPaid * $percentage / 100;
                        ?>

                        <tbody>
                            <?php $__currentLoopData = $paids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($item->department->depart_name); ?></td>
                                    <td><?php echo e($item->subject->subject_name ??'null'); ?></td>
                                    <td><?php echo e($item->student->name); ?></td>
                                    <td><?php echo e($item->total_fees); ?></td>
                                    <td><?php echo e($item->paid); ?></td>
                                    
                                    <td><?php echo e($item->paid_date); ?></td>

                                      <td>
                                        <?php if($teacher->status == 1): ?>
                                            <span class="badge bg-success">Paid</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Unpaid</span>
                                        <?php endif; ?>
                                      </td>

                                       <td style="text-align:center; font-size: 20px;">

                                            <?php if($item->status === 'paid'): ?>
                                                <a href="<?php echo e(route('deactivate.paid', $item->id)); ?>">
                                                    <i class="fas fa-check btn btn-primary waves-effect waves-light"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('deactivate.paid', $item->id)); ?>">
                                                    <i class="fas fa-times btn btn-primary waves-effect waves-light"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>

                                    <?php if($loop->first): ?>
                                        <td rowspan="<?php echo e($paids->count()); ?>" class="text-center font-bold bg-blue-50">
                                            <?php echo e($commission); ?> AFG
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
</div>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views/admin/teacher/index.blade.php ENDPATH**/ ?>