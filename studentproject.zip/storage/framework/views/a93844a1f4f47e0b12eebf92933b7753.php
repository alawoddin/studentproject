<?php $__env->startSection('admin'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


    <div class="container-fluid">

        <!-- Page Title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Edit Paid Admission</h4>
                </div>
            </div>
        </div>

        <!-- Edit Form -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Update Student Payment Info</h4>
                        <form action="<?php echo e(route('update.paid', $paid->id)); ?>" method="POST">

                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="student-dropdown" class="form-label">Select Student</label>
                                    <select name="student_id" id="student-dropdown" class="form-select" required>
                                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($info->id); ?>">
                                                <?php echo e($info->student_name && ($info->name ? 'selected' : '')); ?>

                                                <?php echo e($info->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Department</label>
                                    <select name="department_id" class="form-select" id="department-dropdown">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $depart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($info->id); ?>"
                                                <?php echo e(isset($paid) && $paid->department_id == $info->id ? 'selected' : ''); ?>>
                                                <?php echo e($info->depart_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Subject</label>
                                    <select name="subject_id" class="form-select" id="subject-dropdown">
                                        <option value="">Select Subject</option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>"
                                                <?php echo e($paid->subject_id == $subject->id ? 'selected' : ''); ?>>
                                                <?php echo e($subject->subject_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Teacher</label>
                                    <select name="teacher_id" class="form-select">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($info->id); ?>"
                                                <?php echo e($paid->teacher_id == $info->id ? 'selected' : ''); ?>>
                                                <?php echo e($info->first_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Total Fees</label>
                                    <input class="form-control" name="total_fees" type="text"
                                        value="<?php echo e($paid->total_fees); ?>">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Paid</label>
                                    <input class="form-control" name="paid" type="text" value="<?php echo e($paid->paid); ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Remaining Fees</label>
                                    <input class="form-control" name="remaining_Fees" type="number"
                                        value="<?php echo e($paid->remaining_Fees); ?>">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Entry Date</label>
                                    <input class="form-control" name="entry_date" type="date"
                                        value="<?php echo e($paid->entry_date); ?>">
                                </div>
                            </div>


                            <button type="submit" class="btn btn-success">Update Paid</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <script>
        function calculateRemaining() {
            let total = parseFloat($('#total_fees').val()) || 0;
            let paid = parseFloat($('#paid').val()) || 0;
            let remaining = total - paid;
            $('#remaining_fees').val(remaining >= 0 ? remaining : 0);
        }


        $(document).ready(function () {
            // Recalculate on input changes
            $('#amount, #paid').on('input', calculateRemaining);

            // Initialize on page load
            calculateRemaining();
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\paid\edit_paid.blade.php ENDPATH**/ ?>