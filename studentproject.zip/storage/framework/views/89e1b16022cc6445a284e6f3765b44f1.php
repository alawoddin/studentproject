<?php $__env->startSection('admin'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <div class="container-fluid">

        <!-- Page Title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Teacher Salary </h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="#">Salary</a></li>
                            <li class="breadcrumb-item active">Add</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Expense Form -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Salary Info</h4>
                        <form action="<?php echo e(route('update.salary', $salary->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Department</label>
                                    <select name="department_id" class="form-select" id="department-dropdown">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $depart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($info->id); ?>"
                                                <?php echo e(isset($paid) && $paid->department_id == $info->id ? 'selected' : ''); ?>>
                                                <?php echo e($info->depart_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>


                                <div class="col-md-6">
                                    <label class="form-label">Subject</label>
                                    <select name="subject_id" class="form-select" id="subject-dropdown">
                                        <option value="">Select Subject</option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>"
                                                <?php echo e($salary->subject_id == $subject->id ? 'selected' : ''); ?>>
                                                <?php echo e($subject->subject_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>

                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="col-sm-6 col-form-label">Teacher</label>
                                    
                                        <select name="teacher_id" class="form-select">
                                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($info->id); ?>"
                                                <?php echo e($salary->teacher_id == $info->id ? 'selected' : ''); ?>>
                                                <?php echo e($info->first_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                
                                </div>


                                <div class="col-md-6">
                                    <label class="col-sm-6 col-form-label">salary</label>
                                    
                                        <input class="form-control" id="salary" name="salary" value="<?php echo e($salary->salary); ?>" type="text" placeholder="enter the salary">
                                    
                                </div>
                            </div>



                            
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Add Salary</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\salary\edit_salary.blade.php ENDPATH**/ ?>