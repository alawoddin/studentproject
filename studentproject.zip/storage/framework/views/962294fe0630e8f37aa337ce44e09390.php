<?php $__env->startSection('admin'); ?>

<div class="card">
    <div class="card-body">

        <div class="d-flex justify-content-between">
            <h4 class="card-title">View Student Info</h4>
            <a href="<?php echo e(route('add.pending')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create Student</a>
        </div>

        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="width: 100%;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Lastname</th>
                    <th>Father Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th class="all">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($pend->name); ?></td>
                    <td><?php echo e($pend->lastname); ?></td>
                    <td><?php echo e($pend->father_name); ?></td>
                    <td><?php echo e($pend->phone_number); ?></td>
                    <td><?php echo e($pend->email); ?></td>
                    <td><?php echo e($pend->time); ?></td>
                    <td>
                        <?php if($pend->status === 'done'): ?>
                            <span class="badge bg-success">done</span>
                        <?php elseif($pend->status === 'wait'): ?>
                            <span class="badge bg-warning">wait</span>
                        <?php elseif($pend->status === 'reject'): ?>
                            <span class="badge bg-danger">reject</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="<?php echo e(route('student.pending', $pend->id)); ?>">
                            <?php if($pend->status === 'wait'): ?>
                                <i class="fas fa-spinner btn btn-warning waves-effect waves-light" title="Mark as Done"></i>
                            <?php elseif($pend->status === 'done'): ?>
                                <i class="fas fa-check btn btn-success waves-effect waves-light" title="Already Done"></i>
                            <?php elseif($pend->status === 'reject'): ?>
                                <i class="fas fa-times btn btn-danger waves-effect waves-light" title="Rejected"></i>
                            <?php endif; ?>
                        </a>
                    </td>


                        
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\pending\all_pending.blade.php ENDPATH**/ ?>