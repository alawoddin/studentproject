<?php $__env->startSection('admin'); ?>

<div class="card">
    <div class="card-body">

        <div class="d-flex justify-content-between">
            <h4 class="card-title">View Student Info</h4>
            <a href="<?php echo e(route('add.depart')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create Department</a>
        </div>

        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="width: 100%;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Department</th>
                    <th>Subject</th>
                    <th class="all">Action</th>
                </tr>
            </thead>




          <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($depart->depart_name ?? 'نام ندارد'); ?></td>

                    <td>
                        <?php $__currentLoopData = $depart->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($subject->subject_name); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>

                    <td style="text-align:center; font-size: 20px;">
                        <a href="<?php echo e(route('edit.depart', $depart->id)); ?>"><i class="fas fa-edit btn btn-primary"></i></a>
                        <a href="<?php echo e(route('delete.depart', $depart->id)); ?>" id="delete"><i class="fas fa-trash-alt btn btn-danger"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\department\all_depart.blade.php ENDPATH**/ ?>