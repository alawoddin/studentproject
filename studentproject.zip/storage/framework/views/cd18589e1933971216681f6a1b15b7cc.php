<?php $__env->startSection('admin'); ?>

    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between">
                <h4 class="card-title">View Student Info</h4>
                <a href="<?php echo e(route('add.paid')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create
                    Student</a>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="width: 100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>student</th>
                        <th>Department</th>
                        <th>subject</th>
                        <th>teacher</th>
                        <th>total_fees</th>
                        <th>paid</th>
                        <th>remaining_Fees</th>
                        <th>entry_date</th>
                        <th>paid_date</th>
                        <th>Status</th>
                        <th class="all">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $paid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $paids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($paids->student->name); ?></td>
                            <td><?php echo e($paids->department->depart_name); ?></td>
                            <td><?php echo e($paids->subject->subject_name ??'null'); ?></td>
                            

                            <td><?php echo e($paids->teacher->first_name); ?></td>
                            <td><?php echo e($paids->total_fees); ?></td>
                            <td><?php echo e($paids->paid); ?></td>
                            <td><?php echo e($paids->remaining_Fees); ?></td>
                            <td><?php echo e($paids->entry_date); ?></td>
                            <td><?php echo e($paids->paid_date); ?></td>
                            <td>
                                <?php if($paids->status === 'paid'): ?>
                                    <span class="badge bg-success">paid</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">no_paid</span>
                                <?php endif; ?>
                            </td>

                            <td style="text-align:center; font-size: 20px;">
                                <a href="<?php echo e(route('edit.paid', $paids->id)); ?>">
                                    <i class="fas fa-edit btn btn-primary"></i>
                                </a>
                                <a href="<?php echo e(route('delete.paid', $paids->id)); ?>" id="delete">
                                    <i class="fas fa-trash-alt btn btn-danger"></i>
                                </a>

                                <?php if($paids->status === 'paid'): ?>
                                    <a href="<?php echo e(route('deactivate.paid', $paids->id)); ?>">
                                        <i class="fas fa-check btn btn-primary waves-effect waves-light"></i>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('deactivate.paid', $paids->id)); ?>">
                                        <i class="fas fa-times btn btn-primary waves-effect waves-light"></i>
                                    </a>
                                <?php endif; ?>
                            </td>



                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\paid\manage_paid.blade.php ENDPATH**/ ?>