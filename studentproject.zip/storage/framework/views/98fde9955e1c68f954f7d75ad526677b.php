<?php $__env->startSection('admin'); ?>

    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between">
                <h4 class="card-title">View Student Info</h4>
                <a href="<?php echo e(route('add.paid')); ?>" class="btn btn-primary waves-effect waves-light mb-4">Create
                    Student</a>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="width: 100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>department</th>
                        <th>subject</th>
                        <th>teacher</th>
                        <th>Salary</th>
                        <th>Month</th>
                        <th class="all">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->department->depart_name); ?></td>
                            <td><?php echo e($item->subject->subject_name); ?></td>
                            

                            <td><?php echo e($item->teacher->first_name); ?></td>
                            <td><?php echo e($item->salary); ?></td>
                            <td><?php echo e($item->order_month); ?></td>
                            <td style="text-align:center; font-size: 20px;">
                                <a href="<?php echo e(route('edit.salary', $item->id)); ?>">
                                    <i class="fas fa-edit btn btn-primary"></i>
                                </a>
                                <a href="<?php echo e(route('delete.salary', $item->id)); ?>" id="delete">
                                    <i class="fas fa-trash-alt btn btn-danger"></i>
                                </a>
                            </td>



                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\salary\all_salary.blade.php ENDPATH**/ ?>