<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Bill Invoice</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 0;
            margin: 0;
            background-color: #fff;
            font-size: 12px;
        }

        .invoice-box {
            width: 100%;
            border: 1px solid #000;
            padding: 10px;
        }

        .logo {
            width: 80px;
            height: auto;
            display: block;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table td, table th {
            border: 1px solid #333;
            padding: 4px;
            text-align: left;
        }

        .footer {
            font-size: 11px;
            margin-top: 10px;
            text-align: center;
        }

        .fw-bold {
            font-weight: bold;
        }

        .header-title {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>

</head>

<body>
    <div class="invoice-box">
        <!-- Header -->
        <div class="d-flex justify-content-around align-items-center mb-4 flex-wrap">
            
                <img src="<?php echo e(public_path('uploads/tawana.jpg')); ?>" alt="Logo" class="logo" />





            <div class="bill_number" style="color: green; font-weight: bold">
                Bill NO# <span> <?php echo e($Paid->id); ?></span>
            </div>
        </div>

        <!-- Table -->
        <table class="table table-bordered">
            <tbody>
                <tr>
                    <td class="fw-bold">Register Date</td>
                    <td><?php echo e($Paid->paid_date); ?></td>
                    <td class="fw-bold">First Name</td>
                    <td><?php echo e($Paid->student->name); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Subject</td>
                    <td><?php echo e($Paid->subject->subject_name); ?></td>
                    <td class="fw-bold">Father Name</td>
                    <td><?php echo e($Paid->student->father_name); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Amount</td>
                    <td><?php echo e($Paid->total_fees); ?></td>
                    <td class="fw-bold">Paid Fee</td>
                    <td><?php echo e($Paid->paid); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Remain Fee</td>
                    <td><?php echo e($Paid->remaining_Fees); ?></td>
                    <td class="fw-bold">Time</td>
                    <td><?php echo e($Paid->student->time); ?></td>
                </tr>
            </tbody>
        </table>
        <!-- Footer -->
        <!-- Footer -->
        <div class="footer">
            <p>
                <i class="bi bi-building text-success"></i>
                Tawanatechnology.com
            </p>
            <p>
                <i class="bi bi-telephone-fill text-success"></i>
                +93(0)788077685
            </p>

            <p>
                <i class="bi bi-geo-alt-fill text-success"></i>
                Charahe Polsorkh, Amir Center, Manzel 3rd.
            </p>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views\admin\student\print_invoice.blade.php ENDPATH**/ ?>