<?php $__env->startSection('admin'); ?>

<div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0"> <?php echo e($teacher->first_name); ?></h4>

                                    

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                         <?php
            use App\Models\Paid;

            $paids = Paid::with(['student', 'subject'])
                ->where('teacher_id', $teacher->id)
                ->where('status', 'paid')
                ->get();

            $groupedPaids = $paids->groupBy(function($item) {
                return $item->subject->subject_name ?? 'No Subject';
            });
        ?>


                        <div class="row">
                        <?php $__currentLoopData = $groupedPaids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectName => $paidGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $subjectIdCard = $paidGroup->first()->subject->id ?? null;
                        ?>
                            
                            <div class="col-lg-4">
                                <div class="card m-b-30">
                                    <div class="card-body">

                                        <div class="d-flex align-items-center">
                                            <img class="d-flex me-3 rounded-circle img-thumbnail avatar-lg" src="https://tawanatechnology.com/frontend/images/logo5.png" alt="Generic placeholder image">
                                            <div class="flex-grow-1">
                                                <a href="<?php echo e(route('teacher.index', ['id' => $teacher->id, 'subject_id' => $subjectIdCard])); ?>"><h5 class="mt-0 font-size-18 mb-1"><?php echo e($subjectName); ?></h5></a>
                                                <p class="text-muted font-size-14"><?php echo e($paidGroup->first()->student?->time); ?></p>

                                                <ul class="social-links list-inline mb-0">
                                                     <li class="list-inline-item">
                                                        <a role="button" class="text-reset" title="" data-bs-placement="top" data-bs-toggle="tooltip" class="tooltips" href="<?php echo e(route('teacher.index', ['id' => $teacher->id, 'subject_id' => $subjectIdCard])); ?>"><i class="fas fa-clipboard"></i></a>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div> <!-- end col -->
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div> <!-- end row -->


                     

                    </div> <!-- container-fluid -->
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sayed\OneDrive\Desktop\Excise\studentproject\resources\views/admin/teacher/view_teachers.blade.php ENDPATH**/ ?>